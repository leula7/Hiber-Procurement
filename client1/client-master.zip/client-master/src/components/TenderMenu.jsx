import React from 'react'

const TenderMenu = () => {
  return (
    <div>
      
    </div>
  )
}

export default TenderMenu