import React from 'react'

const SupplierTender = () => {
  return (
    <div>SupplierTender</div>
  )
}

export default SupplierTender