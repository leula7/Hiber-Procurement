import { Box, Typography,Card , CardContent,CardMedia , CardActionArea ,useTheme, Fab, Button, Menu, MenuItem, LinearProgress} from "@mui/material";
import AddProposalDialog from "components/AddProposalDialog";
import GenerateProposalDialog from "components/GenerateProposalDialog";
import Header from "components/Header";
import SetDeadlLine from "components/SetDeadLine";
import UploadDoc from "components/UploadDocDialog";
import { useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useGenerateProposalMutation ,useAddProposalMutation, useUpdateTenderMutation, useGetMyTenderQuery, useGetDocumentQuery} from "state/api";
import Pay from "./pay";

const MyTender = () => {

  const [selectedRow, setSelectedRow] = useState(null);
  const [anchorEl, setAnchorEl] = useState(null);
  const id = useSelector((state) => state.auth.user.supplier_id);
    const {data , isLoading} = useGetMyTenderQuery(id);
    // const {data:h} = useGetDocumentQuery("114");
    // console.log(h)
    console.log(data)
  const openMenu = Boolean(anchorEl);
   const theme = useTheme();
   const navigate= useNavigate()

  const handleClick = (event,values) => {
    setAnchorEl(event.currentTarget);
    setSelectedRow(values)
    console.log(selectedRow)
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleTechnical = () => {
    const supplierid = selectedRow.bid_participate_id;
    const user_id=id;
    navigate(`/mytender/technical/${supplierid}`)  }
 const handleFinancial = () => {
  const bid_participate_id = selectedRow.bid_id;
  const supplierid = selectedRow.bid_participate_id;
  navigate(`/mytender/financial/${bid_participate_id}/${supplierid}`)
 }
 const handleGetDoc = () => {

 }
   const values={
    id:"sa"
   }
    return (
        
        <Box  m="1.5rem 2.5rem" >
          <Header title="MY TENDERS"   />
            <Box
                //  mt="40px"
                display="grid"
                gridTemplateColumns="repeat(4, 1fr)"
                // gridAutoRows="140px"
                gap="20px"
                 > 
                 {data && (
                  <>
                   {data || !isLoading ? (
                  data.map((data) => (
           <Card key={data.bid_participate_id} sx={{ maxWidth: 345 }}>
        
      <CardActionArea onClick={(event) => handleClick(event, data)}>
        <CardMedia
          component="img"
          height="140"
          image="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Y29tcHV0ZXJ8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60"
          alt="Bid image"
        />
        <CardContent>
          <Typography gutterBottom variant="h5" component="div">
           Tender for Year 2023 Computer
          </Typography>
          <Typography variant="h6" color="text.secondary">
            Details:{data.date}
          </Typography>
          <Typography variant="h5"> 
           Status : on going
          </Typography>
        </CardContent>
      </CardActionArea>
            </Card>
            ))
            ) : (
              <LinearProgress variant="success" />
            )}
              </>
              )} 
          
    
    </Box>
    <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={openMenu}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button',
        }}
      >
        <MenuItem onClick={handleTechnical}>Set Technical </MenuItem>
        <MenuItem onClick={handleFinancial}>Set Financial</MenuItem>
        <MenuItem onClick={handleGetDoc}>Download Bid Document</MenuItem>
      </Menu>
     
        </Box>
        
    )
}

export default MyTender;