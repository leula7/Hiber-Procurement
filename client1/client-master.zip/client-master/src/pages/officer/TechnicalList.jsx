import { useTheme } from '@emotion/react';
import { Box } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import Header from 'components/Header';
import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { useGetTechnicalListQuery } from 'state/api';

const TechnicalList = () => {
 const theme = useTheme();
    const [open, setOpen] = useState(false);
    const {bidid} = useParams();
    // console.log(bidid)
    const [selectedRow, setSelectedRow] = useState(null);
    // const id = useSelector((state) => state.auth.user.user_id);
    const navigate= useNavigate();
    const {data , isLoading} = useGetTechnicalListQuery(bidid);
    console.log(data)
  //   const [ setTaskStatus,  ] = useSetTaskStatusMutation();
//  const handleDetail = (id) => {
//     navigate(`/ongoingdetails/technicallist/detail/${bidid}/${id}`)
//   }
   useEffect(() => {
    if (selectedRow) {
      navigate(`/ongoingdetails/technicallist/detail/${bidid}/${selectedRow}`);
    }
  }, [selectedRow,navigate,bidid]);
  
  const handleRowSelection = (params) => {
    setSelectedRow(params.row);
    console.log(selectedRow)
    // handleDetail(selectedRow.technical_id);
  };
  
    const columns = [
      {
        field: "First_Name",
        headerName: "First Name",
        flex: 0.5,
      },
      {
        field: "Last_Name",
        headerName: "Last Name",
        flex: 0.5,
      },
    ];
 
    return (
      <Box m="1.5rem 2.5rem">
        <Header title=" Technical List" subtitle="" />
        <Box
          mt="40px"
          height="70vh"
          sx={{
            "& .MuiDataGrid-root": {
              border: "none",
            },
            "& .MuiDataGrid-cell": {
              borderBottom: "none",
            },
            "& .MuiDataGrid-columnHeaders": {
              backgroundColor: theme.palette.background.alt,
              color: theme.palette.secondary[100],
              borderBottom: "none",
            },
            "& .MuiDataGrid-virtualScroller": {
              backgroundColor: theme.palette.primary.light,
            },
            "& .MuiDataGrid-footerContainer": {
              backgroundColor: theme.palette.background.alt,
              color: theme.palette.secondary[100],
              borderTop: "none",
            },
            "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
              color: `${theme.palette.secondary[200]} !important`,
            },
          }}
        >
          <DataGrid
            loading={isLoading || !data}
            getRowId={(row) => row.bid_participate_id}
            rows={data || []}
            columns={columns}
            onRowClick={handleRowSelection}
          />
        
      </Box>
      </Box>
  )
}

export default TechnicalList