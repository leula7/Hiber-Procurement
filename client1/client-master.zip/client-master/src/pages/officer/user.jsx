import React from 'react'

const user = () => {

  return (
    <div></div>
  )
}

export default user